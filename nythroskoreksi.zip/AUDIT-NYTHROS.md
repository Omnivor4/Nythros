# Audit Nythros — Root Cause Analysis & Rencana Perbaikan

**Scope:** `nythros/` (CLI agent coding, ~408K src, 116M dengan node_modules)
**Metode:** trace semua entry point, cross-check import graph vs kode nyata, verifikasi klaim README vs implementasi, jalankan smoke test atas patch.

---

## TL;DR

Nythros bukan "beberapa bug kecil" — ini project yang tumbuh lewat **pola self-patching berulang tanpa kontrol arsitektur**. Buktinya bahkan ditulis oleh agent-nya sendiri di `Nythros/Nythros/Logs/Nythros Post-Mortem 15 Bugs.md`: 15 bug arsitektural yang sudah pernah "dijanjikan" tidak akan terulang. Tapi audit ini menemukan **5 bug kritis baru** yang tidak ada di daftar itu — termasuk satu yang secara literal mematikan system prompt di kedua entry point (`chat` command dan REPL).

Tiga dari bug kritis sudah saya **perbaiki langsung** di source (lihat bagian "Patch yang sudah diterapkan"). Sisanya adalah keputusan arsitektur yang perlu kamu ambil sendiri karena berdampak besar ke struktur project.

---

## 1. Bug kritis yang saya temukan (dan perbaiki)

### 1.1 — System prompt tidak pernah sampai ke model (`await` hilang)
**File:** `src/cli.js:54`, `src/repl.js:381`

```js
// SEBELUM (bug)
const systemPrompt = buildSystemPrompt({ ... });
```

`buildSystemPrompt()` di `src/agent/systemPrompt.js` adalah fungsi **`async`** (karena ada `import()` dinamis untuk baca archive). Dipanggil tanpa `await`, `systemPrompt` menjadi objek `Promise`, bukan string. Ini terjadi di **kedua** entry point utama (`nythros chat` dan mode interaktif REPL) — artinya persona, memory, daftar tools aktif, instruksi mode (plan/execute), dan instruksi bahasa **tidak pernah benar-benar dikirim ke LLM** dengan isi yang seharusnya.

Ini kemungkinan besar akar dari gejala "agent-nya suka nggak nurut / lupa konteks / nggak pakai tool yang benar" — karena system prompt-nya rusak dari awal, bukan masalah prompt engineering.

**Status: ✅ Diperbaiki** — tambah `await` di kedua tempat, sudah diverifikasi lewat smoke test (`systemPrompt` sekarang string asli, bukan `[object Promise]`).

### 1.2 — `read_file` dan `edit_file` bisa akses file di luar project (termasuk API key plaintext)
**File:** `src/agent/tools.js`

`write_file` sudah benar: dia cek `isProtectedPath()` **dan** memastikan path resolve ke dalam `process.cwd()`. Tapi `read_file` **sama sekali tidak punya pembatasan path** — tidak ada projectRoot check, tidak ada protected-path check. `edit_file` punya `isProtectedPath()` tapi tanpa projectRoot check.

Dampak nyata: agent (atau prompt injection dari konten eksternal yang diproses agent) bisa memanggil `read_file` dengan path `~/.nythros/config.json` — file konfigurasi yang menyimpan **API key dalam bentuk plaintext, tanpa enkripsi, tanpa pembatasan permission file**. Isi file itu lalu muncul di context/transcript, yang berpotensi bocor ke provider LLM manapun yang dipakai (termasuk gateway pihak ketiga seperti OpenRouter kalau user pakai mode `openai-compatible`).

Ditambah: daftar `PROTECTED_PATHS` yang di-hardcode di `agent/tools.js` cuma `["~/.nythros", ".nythros", "config.json"]` — padahal `config.js` sudah punya `safety.protected_paths` yang jauh lebih lengkap (`~/.ssh`, `~/.gnupg`, `~/.config/secrets`, dst). **Config itu tidak pernah dibaca oleh tool manapun** — jadi fitur "protected paths" yang terlihat dikonfigurasi di `config.json` sebenarnya dekoratif, tidak pernah dieksekusi.

**Status: ✅ Diperbaiki** — saya buat satu helper `pathSafetyError()` yang dipakai konsisten oleh `read_file`, `write_file`, dan `edit_file`: cek null-byte, cek terhadap `PROTECTED_PATHS` **plus** `config.safety.protected_paths`, dan enforce containment ke project root. Diverifikasi: `read_file` ke `/etc/hostname` sekarang diblokir, baca file dalam project tetap normal.

### 1.3 — Double-escaped string/regex di memory compression (`src/agent/loop.js`)
```js
// SEBELUM (bug)
.join("\\n")                          // literal karakter \ + n, bukan newline
summary.match(/^[-•*]\\s+.+$/gm)      // regex cari literal backslash, hampir tidak pernah match
```

Efeknya: begitu percakapan panjang di-compress (setelah `memory.compress_after` pesan, default 30), ringkasan konteks yang dikirim balik ke model **berisi teks sampah `\n` literal**, dan ekstraksi `key_points` dari bullet list **selalu kosong** karena regex-nya salah escape. Ini silent — tidak crash, cuma bikin kualitas konteks jangka panjang menurun pelan-pelan tanpa ada error yang kelihatan.

**Status: ✅ Diperbaiki** — 3 titik di `loop.js` sudah dibetulkan escape-nya, syntax-checked dengan `node --check`.

### 1.4 — "Auto" sandbox mode tidak pernah aktif → default-nya unsandboxed shell exec
**File:** `src/config.js` (default `safety.sandbox_mode: "auto"`) vs `src/agent/tools.js` (`runCommandTool`)

README bilang: *"Nythros akan mengecek instalasi Docker daemon... Jika tidak ditemukan, otomatis fallback ke host-exec."* Tapi kode aslinya:

```js
const sandboxMode = config?.safety?.sandbox_mode || "host";
if (sandboxMode === "docker") { ... }   // <-- hanya string persis "docker" yang masuk sini
// selain itu: langsung exec() mentah di host, tanpa isolasi apapun
```

Default config-nya `"auto"` — tapi `runCommandTool` **tidak pernah menangani nilai `"auto"`**, cuma cek `=== "docker"`. Jadi secara default, **semua command jalan langsung di host lewat `child_process.exec()` mentah**, tanpa sandbox, tanpa deteksi Docker apapun — kontradiktif dengan yang diklaim README.

Lapisan proteksi satu-satunya adalah `looksDangerous()` di `utils/confirm.js`: regex blocklist naif (`rm`, `sudo`, `format`, dst). **Blocklist untuk shell command itu secara fundamental tidak bisa diandalkan** — gampang di-bypass (`rm${IFS}-rf`, base64-encoded payload lewat `sh -c`, `python3 -c "import os; os.remove(...)"`, `find / -delete`, dll). Ini bukan celah spesifik yang bisa "ditambal satu regex lagi", tapi kesalahan model keamanan: blocklist tidak pernah cukup untuk shell arbitrary execution.

**Status: ⚠️ Belum saya patch** — ini keputusan desain, bukan one-line fix (lihat rekomendasi §3).

### 1.5 — Arsitektur "split-brain": dua implementasi agent yang berbeda dan tidak sinkron
Ada **dua jalur eksekusi agent yang sepenuhnya independen**:

| | `nythros chat "..."` (single-shot) | Mode REPL interaktif |
|---|---|---|
| Loop | `src/agent/loop.js` | logic custom di `src/repl.js` |
| Tools | `src/agent/tools.js` (`builtinTools`) | `src/agent/orchestrator.js`, `src/agent/router.js`, `src/agent/desktop.js`, `src/tools/pythonExecutor.js`, `src/tools/visionTool.js` |
| MCP servers | ❌ tidak tersedia sama sekali | ✅ tersedia (`src/mcp/client.js`) |
| Memory | `src/memory/memory.js`, `archive.js` | `src/memory/engine.js` |

Konsekuensi paling nyata buat kamu yang minta review lewat sudut pandang **mcp-builder**: **fitur MCP yang dikonfigurasi di `config.mcpServers` cuma jalan di mode REPL interaktif.** Command `nythros chat` yang didokumentasikan sebagai cara pakai utama di README **tidak pernah memuat MCP tools**. Kalau kamu install skill/MCP server, sebagian besar cara pakai Nythros tidak akan pernah melihatnya.

**Status: ⚠️ Belum saya patch** — butuh keputusan: satukan ke satu implementasi, atau migrasikan MCP loading ke `loop.js`/`tools.js` supaya dipakai kedua jalur. Lihat §3.

---

## 2. Dead code — ~30-40% dari `src/` tidak pernah dieksekusi

Verifikasi lewat grep import graph dari kedua entry point (`cli.js` dan `repl.js`):

| File/folder | Status |
|---|---|
| `src/core/ToolExecutor.js` | Tidak diimpor siapapun |
| `src/core/ObservabilityLogger.js` | Tidak diimpor siapapun |
| `src/core/sandbox.js` | Hanya dipakai oleh file dead lainnya (`tools/shell.js`, `tools/docTools.js`, `tools/gamedevTools.js`) |
| `src/tools/*` (seluruh folder: `docTools`, `gamedevTools`, `memoryTools`, `pythonExecutor`, `shell`, `visionTool`) | Duplikat dari `src/agent/*Tools.js` dengan isi **berbeda**, tidak diimpor kecuali oleh sesama file dead — kecuali `pythonExecutor.js` dan `visionTool.js` yang dipakai `repl.js` |
| `src/memory/MemoryManager.js` | Tidak diimpor entry point manapun |
| `src/agent/selfImprove.js` | Diimpor nowhere; kalau dijalankan manual, **crash** — `import { AGENT_TOOLS } from "./tools.js"` padahal `tools.js` cuma export `builtinTools` (lihat `selfImprove_log.txt` bawaan project, ini bug yang sudah kejadian & terekam) |
| `src/evolution/*` | Cuma dipakai `loop.js` untuk logging observasi, bukan loop evolusi aktif |
| Command `nythros self-improve` | Stub kosong: `"Self-improve loop sedang dimigrasi ke arsitektur baru."` |

`src/agent/docTools.js` vs `src/tools/docTools.js` dan `src/agent/gamedevTools.js` vs `src/tools/gamedevTools.js` bukan cuma duplikat nama — **isinya beda** (fungsi berbeda, di bawah nama tool yang sama). Ini pola khas hasil refactor yang ditinggal setengah jalan: file baru dibuat, file lama tidak dihapus, dan tidak ada yang cross-check mana yang benar-benar terpakai.

## 3. Rekomendasi prioritas (sudah dipertimbangkan effort vs impact)

**P0 — sudah saya kerjakan:**
1. ✅ `await buildSystemPrompt()` di `cli.js` & `repl.js`
2. ✅ Konsistensi path-safety di `read_file`/`write_file`/`edit_file`, plus hormati `config.safety.protected_paths`
3. ✅ Fix double-escape di `loop.js`

**P0 — perlu keputusan kamu, saya siap eksekusi begitu kamu pilih arah:**
4. **Model keamanan `run_command`**: ganti dari "blocklist command berbahaya" jadi "Docker sandbox adalah default, host-exec adalah opt-in eksplisit dengan warning". Perbaiki juga branch `sandboxMode === "auto"` supaya benar-benar mendeteksi `docker version` seperti yang diklaim README — sekarang string `"auto"` itu jatuh ke host-exec diam-diam.
5. **Satukan dua arsitektur agent.** Rekomendasi: jadikan `agent/loop.js` + `agent/tools.js` sebagai satu-satunya implementasi (karena itu yang dipakai command utama `chat`), lalu migrasikan kemampuan unik dari jalur REPL (MCP client, vision tool, python executor) supaya jadi tools yang terdaftar di `builtinTools`, bukan sistem paralel. Ini juga otomatis memperbaiki temuan #1.5 (MCP hilang dari `chat` command).

**P1:**
6. Hapus dead code yang terkonfirmasi (`core/ToolExecutor.js`, `core/ObservabilityLogger.js`, `core/sandbox.js`, seluruh `src/tools/*` yang sudah dimigrasikan ke `agent/*`, `memory/MemoryManager.js`) — atau perbaiki & sambungkan kalau memang masih dibutuhkan. Biarkan dead code menumpuk = makin susah tahu mana source of truth.
7. Perbaiki penyimpanan API key: minimal `fs.chmodSync(CONFIG_PATH, 0o600)` setelah `saveConfig()`, dan pertimbangkan OS keychain (mis. lib `keytar`) untuk penyimpanan jangka panjang, bukan JSON plaintext.
8. Perbaiki `agent/selfImprove.js` (import yang salah) atau hapus kalau memang sudah digantikan arsitektur baru — jangan dibiarkan sebagai kode yang pasti crash kalau dipanggil.

**P2 — hygiene:**
9. Repo ini membawa isi vault Obsidian pribadi (`Nythros/Nythros/Logs/*.md`), log crash PowerShell Windows (`selfImprove_log.txt`, `output.txt`), folder aneh (`-p`, `c.txt`), dan `test_project_*` — ini semua kelihatannya kebawa nggak sengaja dari mesin dev. Perketat `.gitignore` dan `files` di `package.json` (yang sebenarnya sudah cukup rapi, tapi nggak menolong kalau foldernya sendiri yang ke-zip/ke-commit).
10. `test_*.js` di root itu ad-hoc script manual, bukan test suite beneran (tidak ada `npm test` yang jalan otomatis, tidak ada CI). Rekomendasi: migrasi ke runner asli (`vitest`/`node --test`) supaya regresi kayak temuan #1.1 dan #1.3 ketahuan sebelum ship, bukan lewat audit manual.

---

## 4. File yang sudah dipatch (siap dipakai)

- `src/cli.js` — fix missing `await`
- `src/repl.js` — fix missing `await`
- `src/agent/loop.js` — fix 3x double-escape
- `src/agent/tools.js` — helper `pathSafetyError()` baru + `read_file`/`write_file`/`edit_file` dikonsolidasi pakai helper itu

Semua sudah lolos `node --check` dan smoke test manual (lihat lampiran kode di conversation). Belum saya jalankan end-to-end lewat `nythros chat` beneran karena sandbox saya tidak punya binary native `@libsql/linux-x64-gnu` yang dibutuhkan `StateManager.js` — itu masalah lingkungan eksekusi saya, bukan sesuatu yang saya sebabkan atau ubah, tapi **kamu tetap perlu test end-to-end di mesin kamu sendiri** sebelum merasa aman men-deploy patch ini.
